import GravityBox from "./html-integration/GravityBox";
import "./style.css";
// import {
// 	Body,
// 	Query,
// 	World,
// 	Scene,
// 	Engine,
// 	Render,
// 	Runner,
// 	Bodies,
// 	Composite,
// 	Mouse,
// 	MouseConstraint,
// 	Events,
// } from "matter-js";

// create an engine
// const engine = Engine.create();

// // create a renderer
// const render = Render.create({
// 	element: document.body,
// 	engine: engine,
// });

const container = document.getElementById("container");

if (!container) {
	throw new Error("container is null");
}

const gravityBox = new GravityBox({
	container: container,
	items: Array.from(document.querySelectorAll(".tag")) as HTMLDivElement[],
});
gravityBox.start();
gravityBox.initGravity();

// create two boxes and a ground
// const circle = Bodies.circle(400, 200, 20, 20);
// const box1 = Bodies.rectangle(450, 50, 80, 80);
// const box2 = Bodies.rectangle(450, 50, 80, 80);
// const box3 = Bodies.rectangle(450, 50, 80, 80);

// const stikyBodies = [circle, box1, box2, box3];

// add all of the bodies to the world
// Composite.add(engine.world, [
// 	circle,
// 	box1,
// 	box2,
// 	box3,
// 	Bodies.rectangle(400, 0, 800, 50, { isStatic: true }),
// 	Bodies.rectangle(400, 600, 800, 50, { isStatic: true }),
// 	Bodies.rectangle(800, 300, 50, 600, { isStatic: true }),
// 	Bodies.rectangle(0, 300, 50, 600, { isStatic: true }),
// ]);

// add mouse control
// const mouse = Mouse.create(render.canvas);
// const mouseConstraint = MouseConstraint.create(engine, {
// 	mouse: mouse,
// 	constraint: {
// 		stiffness: 0.2,
// 		render: {
// 			visible: false,
// 		},
// 	},
// });

// const moveBodyToPosition = (body, position) => {
// 	var dx = position.x - body.position.x;
// 	var dy = position.y - body.position.y;
// 	var distance = Math.sqrt(dx * dx + dy * dy);

// 	// Если объект уже достиг целевых координат, то прекращаем перемещение
// 	if (distance < 5) {
// 		console.log("return");

// 		// Events.off(engine, "beforeUpdate");
// 		return;
// 	}

// 	// Вычисляем вектор перемещения
// 	var speed = distance / 20; // скорость перемещения в пикселях за кадр
// 	// var speed = 16; // скорость перемещения в пикселях за кадр
// 	var vx = (dx / distance) * speed;
// 	var vy = (dy / distance) * speed;

// 	// Перемещаем объект
// 	Body.translate(body, { x: vx, y: vy });
// };

// const target = { x: 0, y: 0 };
// let isMoving = false;

// Events.on(mouseConstraint, "mousedown", (e) => {
// 	engine.gravity.scale = 0;
// 	target.x = e.mouse.position.x;
// 	target.y = e.mouse.position.y;
// 	isMoving = true;
// 	console.log("mousedown");
// });

// Events.on(mouseConstraint, "mousemove", (e) => {
// 	if (!isMoving) {
// 		return;
// 	}

// 	target.x = e.mouse.position.x;
// 	target.y = e.mouse.position.y;
// });

// Events.on(mouseConstraint, "mouseup", () => {
// 	engine.gravity.scale = 0.001;
// 	isMoving = false;
// 	console.log("mouseup");
// });

// Events.on(engine, "beforeUpdate", () => {
// 	// Находим расстояние до целевых координат

// 	if (!isMoving) {
// 		return;
// 	}

// 	stikyBodies.forEach((body) => {
// 		moveBodyToPosition(body, target);
// 	});
// });

// Composite.add(engine.world, mouseConstraint);

// keep the mouse in sync with rendering
// render.mouse = mouse;

// run the renderer
// Render.run(render);

// // create runner
// const runner = Runner.create();

// // run the engine
// Runner.run(runner, engine);
