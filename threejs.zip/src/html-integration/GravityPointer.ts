export default class GravityPointer{
    constructor() {
    }
}