import * as Matter from "matter-js";

type TOptions = {
	parentContainer: HTMLElement;
	container: HTMLElement;
};

export default class GravityBoxItem {
	width: number;
	height: number;
	body: Matter.Body;
	elem: HTMLElement;
	parentContainerRect: DOMRect;

	constructor(options: TOptions) {
		const rect = options.container.getBoundingClientRect();
		this.parentContainerRect = options.parentContainer.getBoundingClientRect();
		console.log(this.parentContainerRect);

		let borderRadius = +window.getComputedStyle(options.container).borderRadius.replace("px", "");
		if (Object.is(borderRadius, NaN)) {
			borderRadius = 0;
		}
		this.width = rect.width;
		this.height = rect.height;
		this.body = Matter.Bodies.rectangle(Math.random() * 500, Math.random() * 500, this.width, this.height, {
			chamfer: {
				radius: borderRadius,
			},
			render: {
				fillStyle: "transparent",
			},
		});

		this.elem = options.container;
	}

	moveToPosition = (position) => {
		var dx = position.x - this.body.position.x;
		var dy = position.y - this.body.position.y;
		var distance = Math.sqrt(dx * dx + dy * dy);

		if (distance < 5) {
			console.log("return");
			return;
		}

		var speed = distance / 20;
		var vx = (dx / distance) * speed;
		var vy = (dy / distance) * speed;

		Matter.Body.translate(this.body, { x: vx, y: vy });
	};

	isBodyPositionInvalid = (top: number, left: number) => {
		return (
			top > this.parentContainerRect.height + this.parentContainerRect.top ||
			top < this.parentContainerRect.top ||
			left > this.parentContainerRect.left + this.parentContainerRect.width ||
			left < this.parentContainerRect.left
		);
	};

	render() {
		const { x, y } = this.body.position;

		const top = y - this.height / 2
		const left = x - this.width / 2

		if (this.isBodyPositionInvalid(top, left)) {
			console.log("invalid position");

			Matter.Body.setPosition(this.body, this.body.positionPrev);
            // Matter.Body.setPosition(this.body, { x: (800 / 2 - this.body.position.x), y: (600 / 2 - this.body.position.y) });
			// return;
		}

		this.elem.style.top = `${top}px`;
		this.elem.style.left = `${left}px`;
		this.elem.style.transform = `rotate(${this.body.angle}rad)`;
	}
}
