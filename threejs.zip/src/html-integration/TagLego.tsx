
import {useEffect, useRef} from "react";
import GravityBox from "@components/TagLego/GravityBox";

const TagLego = () => {
    const ref = useRef<HTMLDivElement>(null)
    const refGravity = useRef<GravityBox>()
    const isInit = useRef(false)

    useEffect(()=>{
        if(ref.current && !isInit.current){

            refGravity.current = new GravityBox({
                container: ref.current,
                items: Array.from(document.querySelectorAll('.tag')) as HTMLDivElement[]
            })
            refGravity.current?.start();
            isInit.current = true;
        }

    },[])

    return (
        <>
            <div ref={ref} style={{borderBottom: '1px solid',width:'100vw', height: '100vh', position:'relative'}}>

                <div id={'tag-1'} className={'tag'}>Teg</div>
                <div className={'tag tag--big'}>
                    <h5>Вакансии</h5>
                    <div>3</div>
                </div>
                <div id={'tag-2'} className={'tag'}>
                    <h5>Hello! :)</h5>
                    <p><a href={"#"}>Go to link</a></p>
                </div>
            </div>

        </>
    );
};

export default TagLego;